var 0015__auto__20200830__1128_8py =
[
    [ "medicines.migrations.0015_auto_20200830_1128.Migration", "classmedicines_1_1migrations_1_10015__auto__20200830__1128_1_1Migration.html", "classmedicines_1_1migrations_1_10015__auto__20200830__1128_1_1Migration" ]
];