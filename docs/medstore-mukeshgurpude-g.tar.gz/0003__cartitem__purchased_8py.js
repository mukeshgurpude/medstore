var 0003__cartitem__purchased_8py =
[
    [ "cart.migrations.0003_cartitem_purchased.Migration", "classcart_1_1migrations_1_10003__cartitem__purchased_1_1Migration.html", "classcart_1_1migrations_1_10003__cartitem__purchased_1_1Migration" ]
];