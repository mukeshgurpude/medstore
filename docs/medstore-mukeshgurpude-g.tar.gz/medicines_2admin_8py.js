var medicines_2admin_8py =
[
    [ "medicines.admin.Setup", "classmedicines_1_1admin_1_1Setup.html", "classmedicines_1_1admin_1_1Setup" ]
];