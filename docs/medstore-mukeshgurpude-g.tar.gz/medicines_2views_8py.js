var medicines_2views_8py =
[
    [ "medicines.views.MedListView", "classmedicines_1_1views_1_1MedListView.html", "classmedicines_1_1views_1_1MedListView" ],
    [ "medicines.views.MedDetailView", "classmedicines_1_1views_1_1MedDetailView.html", "classmedicines_1_1views_1_1MedDetailView" ],
    [ "medicines.views.MedCreateView", "classmedicines_1_1views_1_1MedCreateView.html", "classmedicines_1_1views_1_1MedCreateView" ],
    [ "medicines.views.MedUpdateView", "classmedicines_1_1views_1_1MedUpdateView.html", "classmedicines_1_1views_1_1MedUpdateView" ],
    [ "medicines.views.MedDeleteView", "classmedicines_1_1views_1_1MedDeleteView.html", "classmedicines_1_1views_1_1MedDeleteView" ],
    [ "stream_file", "medicines_2views_8py.html#a2b23e78a78349aa0d754130eac79e3aa", null ]
];