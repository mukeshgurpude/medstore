var 0017__auto__20200830__1141_8py =
[
    [ "medicines.migrations.0017_auto_20200830_1141.Migration", "classmedicines_1_1migrations_1_10017__auto__20200830__1141_1_1Migration.html", "classmedicines_1_1migrations_1_10017__auto__20200830__1141_1_1Migration" ]
];