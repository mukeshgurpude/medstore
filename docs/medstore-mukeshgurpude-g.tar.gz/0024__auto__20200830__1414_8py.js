var 0024__auto__20200830__1414_8py =
[
    [ "medicines.migrations.0024_auto_20200830_1414.Migration", "classmedicines_1_1migrations_1_10024__auto__20200830__1414_1_1Migration.html", "classmedicines_1_1migrations_1_10024__auto__20200830__1414_1_1Migration" ]
];