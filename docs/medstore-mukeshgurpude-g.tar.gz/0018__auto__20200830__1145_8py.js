var 0018__auto__20200830__1145_8py =
[
    [ "medicines.migrations.0018_auto_20200830_1145.Migration", "classmedicines_1_1migrations_1_10018__auto__20200830__1145_1_1Migration.html", "classmedicines_1_1migrations_1_10018__auto__20200830__1145_1_1Migration" ]
];