var cart_2urls_8py =
[
    [ "app_name", "cart_2urls_8py.html#ae6d35656063cdf7fe6bbd94f2f485d15", null ],
    [ "urlpatterns", "cart_2urls_8py.html#a93b0baeb1fa10af912fde6d9f8bab9a1", null ]
];