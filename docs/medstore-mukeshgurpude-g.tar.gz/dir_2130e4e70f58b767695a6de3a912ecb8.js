var dir_2130e4e70f58b767695a6de3a912ecb8 =
[
    [ "__init__.py", "api_2fixtures_2____init_____8py.html", null ]
];