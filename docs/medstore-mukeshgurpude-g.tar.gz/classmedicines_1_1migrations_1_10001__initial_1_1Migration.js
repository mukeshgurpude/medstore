var classmedicines_1_1migrations_1_10001__initial_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10001__initial_1_1Migration.html#a3cf4a3917566077a76392d8ab1b5cd53", null ],
    [ "initial", "classmedicines_1_1migrations_1_10001__initial_1_1Migration.html#ac1824abc5effe7d1ffe0d82fa5d47e86", null ],
    [ "operations", "classmedicines_1_1migrations_1_10001__initial_1_1Migration.html#a6355449dabd1fc3133332c3f48a203c0", null ]
];