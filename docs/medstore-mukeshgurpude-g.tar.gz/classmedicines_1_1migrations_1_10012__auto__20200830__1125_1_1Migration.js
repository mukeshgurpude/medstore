var classmedicines_1_1migrations_1_10012__auto__20200830__1125_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10012__auto__20200830__1125_1_1Migration.html#ab796426d2a3246f8266d5144243bd787", null ],
    [ "operations", "classmedicines_1_1migrations_1_10012__auto__20200830__1125_1_1Migration.html#a77d3e78cab990e72f384fe88862e4bc2", null ]
];