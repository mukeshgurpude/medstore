var classaccounts_1_1models_1_1UserProfile =
[
    [ "__str__", "classaccounts_1_1models_1_1UserProfile.html#a73802e57a4f13ea325f5cfd860fe04e6", null ],
    [ "full_name", "classaccounts_1_1models_1_1UserProfile.html#a01d31419092ee992eff4cfbc23d8506b", null ],
    [ "gender", "classaccounts_1_1models_1_1UserProfile.html#a6f8c6e54002d8dfc5734fc21765c20a0", null ],
    [ "phone", "classaccounts_1_1models_1_1UserProfile.html#a2deeb28e63af942e84f738b00fddab90", null ],
    [ "user", "classaccounts_1_1models_1_1UserProfile.html#aa816d168487d05f0f8597b8993e0ee28", null ]
];