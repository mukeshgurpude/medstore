var classmedicines_1_1migrations_1_10022__auto__20200830__1401_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10022__auto__20200830__1401_1_1Migration.html#a91108bf109c510ceea639befec4bdd3a", null ],
    [ "operations", "classmedicines_1_1migrations_1_10022__auto__20200830__1401_1_1Migration.html#a29025533ce4696fcf73b34e0f4adda8f", null ]
];