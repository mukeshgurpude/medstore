var namespaceaccounts_1_1migrations =
[
    [ "0001_initial", "namespaceaccounts_1_1migrations_1_10001__initial.html", "namespaceaccounts_1_1migrations_1_10001__initial" ],
    [ "0002_auto_20200908_1336", "namespaceaccounts_1_1migrations_1_10002__auto__20200908__1336.html", "namespaceaccounts_1_1migrations_1_10002__auto__20200908__1336" ]
];