var classmedicines_1_1migrations_1_10021__auto__20200830__1148_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10021__auto__20200830__1148_1_1Migration.html#ae9e64fd205773ce83d148b996c2a906a", null ],
    [ "operations", "classmedicines_1_1migrations_1_10021__auto__20200830__1148_1_1Migration.html#afdf8b66e04065477a2d0d5765b54b115", null ]
];