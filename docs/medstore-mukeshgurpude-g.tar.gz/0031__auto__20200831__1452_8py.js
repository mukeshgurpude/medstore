var 0031__auto__20200831__1452_8py =
[
    [ "medicines.migrations.0031_auto_20200831_1452.Migration", "classmedicines_1_1migrations_1_10031__auto__20200831__1452_1_1Migration.html", "classmedicines_1_1migrations_1_10031__auto__20200831__1452_1_1Migration" ]
];