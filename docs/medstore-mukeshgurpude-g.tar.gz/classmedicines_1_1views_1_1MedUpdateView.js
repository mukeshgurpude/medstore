var classmedicines_1_1views_1_1MedUpdateView =
[
    [ "get", "classmedicines_1_1views_1_1MedUpdateView.html#a4c4733619745ad82d76f8e31aff0fea2", null ],
    [ "post", "classmedicines_1_1views_1_1MedUpdateView.html#ad209c17e86c5ef2d7e8d6c2852c8224b", null ],
    [ "model", "classmedicines_1_1views_1_1MedUpdateView.html#a60f09d205da52f66f92fdeda420602e4", null ],
    [ "success_url", "classmedicines_1_1views_1_1MedUpdateView.html#a3821d75623d3f197d6a4ea757b2b7fe0", null ],
    [ "success_url", "classmedicines_1_1views_1_1MedUpdateView.html#ad1def37502e73eae23f8291ac973bd05", null ],
    [ "template_name", "classmedicines_1_1views_1_1MedUpdateView.html#a924f5ed69fb71cd6485a1a0e8d1a9bc0", null ],
    [ "template_name", "classmedicines_1_1views_1_1MedUpdateView.html#a2ddd39e32ff5ec4584ea295760e17035", null ]
];