var classapi_1_1views_1_1auth_1_1ProfileView =
[
    [ "get", "classapi_1_1views_1_1auth_1_1ProfileView.html#aa3131f169090025ad9485a8a7c6bda43", null ],
    [ "post", "classapi_1_1views_1_1auth_1_1ProfileView.html#a411d6c7a0c24391a5878aaf37c37d0ee", null ]
];