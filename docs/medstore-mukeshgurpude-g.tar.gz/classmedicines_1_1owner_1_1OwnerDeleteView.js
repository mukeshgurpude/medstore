var classmedicines_1_1owner_1_1OwnerDeleteView =
[
    [ "get_queryset", "classmedicines_1_1owner_1_1OwnerDeleteView.html#adccdfbc96ef006ef1681aa5c30e96944", null ]
];