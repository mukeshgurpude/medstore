var dir_617f417d504f020f37da18872da03f47 =
[
    [ "__init__.py", "medical_2____init_____8py.html", null ],
    [ "asgi.py", "asgi_8py.html", "asgi_8py" ],
    [ "dev.py", "dev_8py.html", "dev_8py" ],
    [ "settings.py", "settings_8py.html", "settings_8py" ],
    [ "sitemaps.py", "medical_2sitemaps_8py.html", "medical_2sitemaps_8py" ],
    [ "urls.py", "medical_2urls_8py.html", "medical_2urls_8py" ],
    [ "wsgi.py", "wsgi_8py.html", "wsgi_8py" ]
];