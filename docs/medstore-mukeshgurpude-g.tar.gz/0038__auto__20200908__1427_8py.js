var 0038__auto__20200908__1427_8py =
[
    [ "medicines.migrations.0038_auto_20200908_1427.Migration", "classmedicines_1_1migrations_1_10038__auto__20200908__1427_1_1Migration.html", "classmedicines_1_1migrations_1_10038__auto__20200908__1427_1_1Migration" ]
];