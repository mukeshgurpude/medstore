var 0025__auto__20200830__1559_8py =
[
    [ "medicines.migrations.0025_auto_20200830_1559.Migration", "classmedicines_1_1migrations_1_10025__auto__20200830__1559_1_1Migration.html", "classmedicines_1_1migrations_1_10025__auto__20200830__1559_1_1Migration" ]
];