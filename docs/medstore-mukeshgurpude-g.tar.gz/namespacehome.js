var namespacehome =
[
    [ "apps", "namespacehome_1_1apps.html", "namespacehome_1_1apps" ],
    [ "forms", "namespacehome_1_1forms.html", "namespacehome_1_1forms" ],
    [ "tests", "namespacehome_1_1tests.html", null ],
    [ "urls", "namespacehome_1_1urls.html", [
      [ "app_name", "namespacehome_1_1urls.html#ab827e9f9f3471e545f9842560ca48c76", null ],
      [ "urlpatterns", "namespacehome_1_1urls.html#a7a32da8728aa97f3811ad59693728274", null ]
    ] ],
    [ "views", "namespacehome_1_1views.html", "namespacehome_1_1views" ]
];