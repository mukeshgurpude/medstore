var namespacemedicines_1_1migrations_1_10001__initial =
[
    [ "Migration", "classmedicines_1_1migrations_1_10001__initial_1_1Migration.html", "classmedicines_1_1migrations_1_10001__initial_1_1Migration" ]
];