var 0036__auto__20200908__1336_8py =
[
    [ "medicines.migrations.0036_auto_20200908_1336.Migration", "classmedicines_1_1migrations_1_10036__auto__20200908__1336_1_1Migration.html", "classmedicines_1_1migrations_1_10036__auto__20200908__1336_1_1Migration" ]
];