var classmedicines_1_1views_1_1MedCreateView =
[
    [ "get", "classmedicines_1_1views_1_1MedCreateView.html#ab94ce89be11e25047ccd527b57f8e539", null ],
    [ "post", "classmedicines_1_1views_1_1MedCreateView.html#aaf22fdc8b615c4bca4fbe5b839de8ffc", null ],
    [ "model", "classmedicines_1_1views_1_1MedCreateView.html#a2935e5111bdb972d8325972635625a83", null ],
    [ "permission_denied_message", "classmedicines_1_1views_1_1MedCreateView.html#a77e74a5ef0b4e87b962f1741a18fe301", null ],
    [ "permission_required", "classmedicines_1_1views_1_1MedCreateView.html#a0f6f5befc74d31e7a3ad4e7ae98cccbe", null ],
    [ "success_url", "classmedicines_1_1views_1_1MedCreateView.html#a1f797aca8b478c1f4ba30327f9c6f406", null ],
    [ "template_name", "classmedicines_1_1views_1_1MedCreateView.html#aaaece729377ef9f3dc813f66238c43a1", null ],
    [ "template_name", "classmedicines_1_1views_1_1MedCreateView.html#aba6db25861ad84387f9eb31e1971b819", null ]
];