var namespacemedicines_1_1migrations_1_10040__auto__20200915__0720 =
[
    [ "Migration", "classmedicines_1_1migrations_1_10040__auto__20200915__0720_1_1Migration.html", "classmedicines_1_1migrations_1_10040__auto__20200915__0720_1_1Migration" ]
];