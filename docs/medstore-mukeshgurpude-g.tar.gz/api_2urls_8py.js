var api_2urls_8py =
[
    [ "app_name", "api_2urls_8py.html#ae478470e4b65654f35e525ca4c80fa32", null ],
    [ "urlpatterns", "api_2urls_8py.html#ae1c754cb38c35b590f6a741ace140a07", null ]
];