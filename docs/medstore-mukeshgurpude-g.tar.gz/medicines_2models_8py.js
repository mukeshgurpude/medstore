var medicines_2models_8py =
[
    [ "medicines.models.MedCat", "classmedicines_1_1models_1_1MedCat.html", "classmedicines_1_1models_1_1MedCat" ],
    [ "medicines.models.MedCat.Meta", "classmedicines_1_1models_1_1MedCat_1_1Meta.html", "classmedicines_1_1models_1_1MedCat_1_1Meta" ],
    [ "medicines.models.Medicine", "classmedicines_1_1models_1_1Medicine.html", "classmedicines_1_1models_1_1Medicine" ],
    [ "medicines.models.Medicine.Meta", "classmedicines_1_1models_1_1Medicine_1_1Meta.html", "classmedicines_1_1models_1_1Medicine_1_1Meta" ]
];