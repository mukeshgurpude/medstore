var api_2apps_8py =
[
    [ "api.apps.ApiConfig", "classapi_1_1apps_1_1ApiConfig.html", "classapi_1_1apps_1_1ApiConfig" ]
];