var namespacemedicines_1_1migrations_1_10029__auto__20200831__1340 =
[
    [ "Migration", "classmedicines_1_1migrations_1_10029__auto__20200831__1340_1_1Migration.html", "classmedicines_1_1migrations_1_10029__auto__20200831__1340_1_1Migration" ]
];