var 0010__auto__20200830__1000_8py =
[
    [ "medicines.migrations.0010_auto_20200830_1000.Migration", "classmedicines_1_1migrations_1_10010__auto__20200830__1000_1_1Migration.html", "classmedicines_1_1migrations_1_10010__auto__20200830__1000_1_1Migration" ]
];