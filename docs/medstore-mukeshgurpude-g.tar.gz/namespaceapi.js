var namespaceapi =
[
    [ "apps", "namespaceapi_1_1apps.html", "namespaceapi_1_1apps" ],
    [ "decorators", "namespaceapi_1_1decorators.html", [
      [ "check_response", "namespaceapi_1_1decorators.html#a5b660d5c1d4201518c45dd925a857674", null ]
    ] ],
    [ "tests", "namespaceapi_1_1tests.html", "namespaceapi_1_1tests" ],
    [ "urls", "namespaceapi_1_1urls.html", [
      [ "app_name", "namespaceapi_1_1urls.html#ae478470e4b65654f35e525ca4c80fa32", null ],
      [ "urlpatterns", "namespaceapi_1_1urls.html#ae1c754cb38c35b590f6a741ace140a07", null ]
    ] ],
    [ "views", "namespaceapi_1_1views.html", "namespaceapi_1_1views" ]
];