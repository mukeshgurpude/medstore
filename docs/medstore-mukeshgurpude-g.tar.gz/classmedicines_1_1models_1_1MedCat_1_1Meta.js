var classmedicines_1_1models_1_1MedCat_1_1Meta =
[
    [ "verbose_name", "classmedicines_1_1models_1_1MedCat_1_1Meta.html#a77d7ecfec222c2cbe5ecac8e156df1e8", null ]
];