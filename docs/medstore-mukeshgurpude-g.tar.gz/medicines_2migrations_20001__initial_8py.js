var medicines_2migrations_20001__initial_8py =
[
    [ "medicines.migrations.0001_initial.Migration", "classmedicines_1_1migrations_1_10001__initial_1_1Migration.html", "classmedicines_1_1migrations_1_10001__initial_1_1Migration" ]
];