var 0030__auto__20200831__1426_8py =
[
    [ "medicines.migrations.0030_auto_20200831_1426.Migration", "classmedicines_1_1migrations_1_10030__auto__20200831__1426_1_1Migration.html", "classmedicines_1_1migrations_1_10030__auto__20200831__1426_1_1Migration" ]
];