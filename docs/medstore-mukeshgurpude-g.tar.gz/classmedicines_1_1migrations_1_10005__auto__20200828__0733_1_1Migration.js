var classmedicines_1_1migrations_1_10005__auto__20200828__0733_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10005__auto__20200828__0733_1_1Migration.html#a9bcba2fd8d4165fa5865fd29b1c5366d", null ],
    [ "operations", "classmedicines_1_1migrations_1_10005__auto__20200828__0733_1_1Migration.html#a4c1ff054c792901e8bee8c46cf9f751f", null ]
];