var classmedicines_1_1migrations_1_10008__auto__20200828__1614_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10008__auto__20200828__1614_1_1Migration.html#a7178bbf19d3c2ac44cc3f36b1b28c041", null ],
    [ "operations", "classmedicines_1_1migrations_1_10008__auto__20200828__1614_1_1Migration.html#a514ea78f515c154973f0520170a60133", null ]
];