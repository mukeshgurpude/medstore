var classmedicines_1_1migrations_1_10017__auto__20200830__1141_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10017__auto__20200830__1141_1_1Migration.html#ad6812a435cec1da002d675daeaa0f3fb", null ],
    [ "operations", "classmedicines_1_1migrations_1_10017__auto__20200830__1141_1_1Migration.html#ad2107dc759a586476da11b2de9954e3f", null ]
];