var classapi_1_1views_1_1medicine_1_1APIDetailView =
[
    [ "__init__", "classapi_1_1views_1_1medicine_1_1APIDetailView.html#ad2d843403ae7eaef6296ab196ef9c174", null ],
    [ "get", "classapi_1_1views_1_1medicine_1_1APIDetailView.html#aa978b0f9744a9530dd83c473bc21cff6", null ],
    [ "get_med", "classapi_1_1views_1_1medicine_1_1APIDetailView.html#a5c6e188a766e83ebcb9e50a71b0c34ff", null ],
    [ "post", "classapi_1_1views_1_1medicine_1_1APIDetailView.html#a92cc172431e928128789c50d0ef533cd", null ],
    [ "user", "classapi_1_1views_1_1medicine_1_1APIDetailView.html#ad2e4bf09a75526d5a744e554e2e59210", null ]
];