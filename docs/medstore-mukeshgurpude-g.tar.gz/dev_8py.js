var dev_8py =
[
    [ "ALLOWED_HOSTS", "dev_8py.html#a78ea4e6302956ba679481bbc6835d77a", null ],
    [ "CORS_ALLOW_CREDENTIALS", "dev_8py.html#afb26d6cfcb1c07c12d54ada2c0612e15", null ],
    [ "CORS_ORIGIN_ALLOW_ALL", "dev_8py.html#a4d197dee6415a26dd6065bcd7b54c08f", null ],
    [ "DEBUG", "dev_8py.html#a89f7762951912180414f4160b8deb4e4", null ],
    [ "EMAIL_HOST_PASSWORD", "dev_8py.html#acdb9dad1d4f6599eefe78052eb364e08", null ],
    [ "EMAIL_HOST_USER", "dev_8py.html#ad866ab101ebac9076ab2c6e25b16a4ed", null ]
];