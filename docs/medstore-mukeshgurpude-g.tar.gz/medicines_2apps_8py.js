var medicines_2apps_8py =
[
    [ "medicines.apps.MedicinesConfig", "classmedicines_1_1apps_1_1MedicinesConfig.html", "classmedicines_1_1apps_1_1MedicinesConfig" ]
];