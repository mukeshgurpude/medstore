var 0004__cartitem__total_8py =
[
    [ "cart.migrations.0004_cartitem_total.Migration", "classcart_1_1migrations_1_10004__cartitem__total_1_1Migration.html", "classcart_1_1migrations_1_10004__cartitem__total_1_1Migration" ]
];