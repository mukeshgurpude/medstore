var 0020__auto__20200830__1146_8py =
[
    [ "medicines.migrations.0020_auto_20200830_1146.Migration", "classmedicines_1_1migrations_1_10020__auto__20200830__1146_1_1Migration.html", "classmedicines_1_1migrations_1_10020__auto__20200830__1146_1_1Migration" ]
];