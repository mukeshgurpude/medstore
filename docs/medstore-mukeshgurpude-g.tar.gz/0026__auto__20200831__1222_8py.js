var 0026__auto__20200831__1222_8py =
[
    [ "medicines.migrations.0026_auto_20200831_1222.Migration", "classmedicines_1_1migrations_1_10026__auto__20200831__1222_1_1Migration.html", "classmedicines_1_1migrations_1_10026__auto__20200831__1222_1_1Migration" ]
];