var 0004__auto__20200827__1941_8py =
[
    [ "medicines.migrations.0004_auto_20200827_1941.Migration", "classmedicines_1_1migrations_1_10004__auto__20200827__1941_1_1Migration.html", "classmedicines_1_1migrations_1_10004__auto__20200827__1941_1_1Migration" ]
];