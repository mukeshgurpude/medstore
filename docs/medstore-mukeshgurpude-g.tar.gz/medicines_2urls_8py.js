var medicines_2urls_8py =
[
    [ "app_name", "medicines_2urls_8py.html#aeed16a62b0c51246cd2aa00b3de8dbbb", null ],
    [ "urlpatterns", "medicines_2urls_8py.html#a65e772c4d3f40ee044fd5beef9c4ab6b", null ]
];