var 0002__auto__20200826__1711_8py =
[
    [ "medicines.migrations.0002_auto_20200826_1711.Migration", "classmedicines_1_1migrations_1_10002__auto__20200826__1711_1_1Migration.html", "classmedicines_1_1migrations_1_10002__auto__20200826__1711_1_1Migration" ]
];