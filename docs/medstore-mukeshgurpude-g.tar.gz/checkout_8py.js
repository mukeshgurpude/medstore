var checkout_8py =
[
    [ "api.views.checkout.APIBillingAddress", "classapi_1_1views_1_1checkout_1_1APIBillingAddress.html", "classapi_1_1views_1_1checkout_1_1APIBillingAddress" ],
    [ "order_success", "checkout_8py.html#a87404aa38ae5b07c26c292a62d1cdd62", null ]
];