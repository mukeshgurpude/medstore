var medicines_2forms_8py =
[
    [ "medicines.forms.CreateForm", "classmedicines_1_1forms_1_1CreateForm.html", "classmedicines_1_1forms_1_1CreateForm" ],
    [ "medicines.forms.CreateForm.Meta", "classmedicines_1_1forms_1_1CreateForm_1_1Meta.html", "classmedicines_1_1forms_1_1CreateForm_1_1Meta" ]
];