var classmedicines_1_1views_1_1MedDetailView =
[
    [ "model", "classmedicines_1_1views_1_1MedDetailView.html#a727d168baab3a58bb351cd9f807ff3f9", null ],
    [ "template_name", "classmedicines_1_1views_1_1MedDetailView.html#a0e0528ea78b45c19f64bad1e7a2c5744", null ]
];