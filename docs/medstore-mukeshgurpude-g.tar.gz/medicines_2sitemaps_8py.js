var medicines_2sitemaps_8py =
[
    [ "medicines.sitemaps.MedSiteMap", "classmedicines_1_1sitemaps_1_1MedSiteMap.html", "classmedicines_1_1sitemaps_1_1MedSiteMap" ]
];