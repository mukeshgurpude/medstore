var namespacemedicines_1_1views =
[
    [ "MedCreateView", "classmedicines_1_1views_1_1MedCreateView.html", "classmedicines_1_1views_1_1MedCreateView" ],
    [ "MedDeleteView", "classmedicines_1_1views_1_1MedDeleteView.html", "classmedicines_1_1views_1_1MedDeleteView" ],
    [ "MedDetailView", "classmedicines_1_1views_1_1MedDetailView.html", "classmedicines_1_1views_1_1MedDetailView" ],
    [ "MedListView", "classmedicines_1_1views_1_1MedListView.html", "classmedicines_1_1views_1_1MedListView" ],
    [ "MedUpdateView", "classmedicines_1_1views_1_1MedUpdateView.html", "classmedicines_1_1views_1_1MedUpdateView" ],
    [ "stream_file", "namespacemedicines_1_1views.html#a2b23e78a78349aa0d754130eac79e3aa", null ]
];