var classcart_1_1migrations_1_10003__cartitem__purchased_1_1Migration =
[
    [ "dependencies", "classcart_1_1migrations_1_10003__cartitem__purchased_1_1Migration.html#a40e64dafccada9bf5eb8a669b7a4cd42", null ],
    [ "operations", "classcart_1_1migrations_1_10003__cartitem__purchased_1_1Migration.html#abd7486c354eace51eab49612deee0458", null ]
];