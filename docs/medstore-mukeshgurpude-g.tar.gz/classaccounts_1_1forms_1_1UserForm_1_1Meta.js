var classaccounts_1_1forms_1_1UserForm_1_1Meta =
[
    [ "fields", "classaccounts_1_1forms_1_1UserForm_1_1Meta.html#a9ff72c47bb6a77e6ca8604b844ee9828", null ],
    [ "model", "classaccounts_1_1forms_1_1UserForm_1_1Meta.html#ade0749cdb2d112102e3a90d3ca36a56a", null ]
];