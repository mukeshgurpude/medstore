var 0003__medicine__slug_8py =
[
    [ "medicines.migrations.0003_medicine_slug.Migration", "classmedicines_1_1migrations_1_10003__medicine__slug_1_1Migration.html", "classmedicines_1_1migrations_1_10003__medicine__slug_1_1Migration" ]
];