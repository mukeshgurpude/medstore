var searchData=
[
  ['verbose_5fname_0',['verbose_name',['../classmedicines_1_1models_1_1MedCat_1_1Meta.html#a77d7ecfec222c2cbe5ecac8e156df1e8',1,'medicines::models::MedCat::Meta']]],
  ['views_2epy_1',['views.py',['../accounts_2views_8py.html',1,'(Global Namespace)'],['../cart_2views_8py.html',1,'(Global Namespace)'],['../checkout_2views_8py.html',1,'(Global Namespace)'],['../home_2views_8py.html',1,'(Global Namespace)'],['../medicines_2views_8py.html',1,'(Global Namespace)']]]
];
