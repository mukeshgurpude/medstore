var searchData=
[
  ['quantity_0',['quantity',['../classcart_1_1models_1_1CartItem.html#a8c2fd79e60110a9025352fe94b60c48f',1,'cart.models.CartItem.quantity'],['../classmedicines_1_1models_1_1Medicine.html#a93503a3fcbb8337f341f4f8b5ce1bda6',1,'medicines.models.Medicine.quantity']]]
];
