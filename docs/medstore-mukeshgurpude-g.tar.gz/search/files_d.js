var searchData=
[
  ['views_2epy_0',['views.py',['../accounts_2views_8py.html',1,'(Global Namespace)'],['../cart_2views_8py.html',1,'(Global Namespace)'],['../checkout_2views_8py.html',1,'(Global Namespace)'],['../home_2views_8py.html',1,'(Global Namespace)'],['../medicines_2views_8py.html',1,'(Global Namespace)']]]
];
