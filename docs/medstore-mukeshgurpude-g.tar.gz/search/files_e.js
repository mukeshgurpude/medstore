var searchData=
[
  ['wsgi_2epy_0',['wsgi.py',['../wsgi_8py.html',1,'']]]
];
