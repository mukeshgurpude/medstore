var searchData=
[
  ['register_0',['register',['../namespacecart__tag.html#ae79793a9d2296178b50a1869d25d32d7',1,'cart_tag']]],
  ['res_1',['res',['../classapi_1_1tests_1_1test__auth_1_1ProfileTestCase.html#af1440e9c26c304f73ef759713f420fac',1,'api::tests::test_auth::ProfileTestCase']]],
  ['root_5furlconf_2',['ROOT_URLCONF',['../namespacemedical_1_1settings.html#af6373a3153976f2668b13a750f73a2c2',1,'medical::settings']]]
];
