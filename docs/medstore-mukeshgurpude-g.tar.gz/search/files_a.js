var searchData=
[
  ['settings_2epy_0',['settings.py',['../settings_8py.html',1,'']]],
  ['sitemaps_2epy_1',['sitemaps.py',['../accounts_2sitemaps_8py.html',1,'(Global Namespace)'],['../medical_2sitemaps_8py.html',1,'(Global Namespace)'],['../medicines_2sitemaps_8py.html',1,'(Global Namespace)']]]
];
