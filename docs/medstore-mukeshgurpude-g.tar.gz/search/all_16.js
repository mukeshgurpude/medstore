var searchData=
[
  ['wsgi_2epy_0',['wsgi.py',['../wsgi_8py.html',1,'']]],
  ['wsgi_5fapplication_1',['WSGI_APPLICATION',['../namespacemedical_1_1settings.html#a18e0e98e137e1a356b6ab2d58d0ba12a',1,'medical::settings']]]
];
