var searchData=
[
  ['remove_5ffrom_5fcart_0',['remove_from_cart',['../namespacecart_1_1views.html#a3021e91e344805a0cfdc9c5d1300d3f3',1,'cart::views']]]
];
