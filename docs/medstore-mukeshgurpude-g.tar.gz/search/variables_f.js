var searchData=
[
  ['search_5ffields_0',['search_fields',['../classmedicines_1_1admin_1_1Setup.html#a3a31d3a2719e8b3d759a655187ef80ac',1,'medicines::admin::Setup']]],
  ['secret_5fkey_1',['SECRET_KEY',['../namespacemedical_1_1settings.html#a4fa7323b543d63548865e7c79c3bf0bf',1,'medical::settings']]],
  ['site_5fid_2',['SITE_ID',['../namespacemedical_1_1settings.html#ab72cf3e00a245d600134e53514f14a3c',1,'medical::settings']]],
  ['sitemaps_3',['sitemaps',['../namespacemedical_1_1urls.html#a1bcac7cc9be757691b95009d2cbc5b0c',1,'medical::urls']]],
  ['slug_4',['slug',['../classmedicines_1_1models_1_1Medicine.html#afbb5fbd3a7b0fc89159c717bf6a64089',1,'medicines::models::Medicine']]],
  ['static_5furl_5',['STATIC_URL',['../namespacemedical_1_1settings.html#aed486632e3987437ea34a38a2ff15f9e',1,'medical::settings']]],
  ['store_5fdata_6',['STORE_DATA',['../namespaceapi_1_1tests_1_1test__auth.html#aa26b03aec66735f726ea42bb62e99851',1,'api::tests::test_auth']]],
  ['store_5fname_7',['store_name',['../classaccounts_1_1models_1_1SellerProfile.html#affcdefeaa21ea022201b33c287ca823c',1,'accounts::models::SellerProfile']]],
  ['str_5fpub_8',['STR_PUB',['../namespacemedical_1_1settings.html#a25af291aa87cc96682c2a94ef1b2aea4',1,'medical::settings']]],
  ['str_5fsec_9',['STR_SEC',['../namespacemedical_1_1settings.html#a1590172e975edce9402f9808caa86de0',1,'medical::settings']]],
  ['stripe_5fendpoint_5fkey_10',['STRIPE_ENDPOINT_KEY',['../namespacemedical_1_1settings.html#aea457faa0dde02962ad7fe4cf104326e',1,'medical::settings']]],
  ['success_5furl_11',['success_url',['../classmedicines_1_1views_1_1MedCreateView.html#a1f797aca8b478c1f4ba30327f9c6f406',1,'medicines.views.MedCreateView.success_url'],['../classmedicines_1_1views_1_1MedUpdateView.html#a3821d75623d3f197d6a4ea757b2b7fe0',1,'medicines.views.MedUpdateView.success_url'],['../classmedicines_1_1views_1_1MedUpdateView.html#ad1def37502e73eae23f8291ac973bd05',1,'medicines.views.MedUpdateView.success_url']]]
];
