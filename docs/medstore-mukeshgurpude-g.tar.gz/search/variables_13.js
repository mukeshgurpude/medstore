var searchData=
[
  ['wsgi_5fapplication_0',['WSGI_APPLICATION',['../namespacemedical_1_1settings.html#a18e0e98e137e1a356b6ab2d58d0ba12a',1,'medical::settings']]]
];
