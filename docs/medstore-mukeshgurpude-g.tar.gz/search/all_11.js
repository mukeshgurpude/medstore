var searchData=
[
  ['readme_2emd_0',['README.md',['../README_8md.html',1,'']]],
  ['register_1',['register',['../namespacecart__tag.html#ae79793a9d2296178b50a1869d25d32d7',1,'cart_tag']]],
  ['remove_5ffrom_5fcart_2',['remove_from_cart',['../namespacecart_1_1views.html#a3021e91e344805a0cfdc9c5d1300d3f3',1,'cart::views']]],
  ['res_3',['res',['../classapi_1_1tests_1_1test__auth_1_1ProfileTestCase.html#af1440e9c26c304f73ef759713f420fac',1,'api::tests::test_auth::ProfileTestCase']]],
  ['root_5furlconf_4',['ROOT_URLCONF',['../namespacemedical_1_1settings.html#af6373a3153976f2668b13a750f73a2c2',1,'medical::settings']]],
  ['run_20locally_5',['How to run Locally',['../md__2tmp_2github__repos__arch__doc__gen_2mukeshgurpude_2medstore_2README.html#autotoc_md0',1,'']]]
];
