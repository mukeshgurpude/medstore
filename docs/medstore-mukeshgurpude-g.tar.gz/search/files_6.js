var searchData=
[
  ['humanize_2epy_0',['humanize.py',['../humanize_8py.html',1,'']]]
];
