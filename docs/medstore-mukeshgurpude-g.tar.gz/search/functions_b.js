var searchData=
[
  ['naturalsize_0',['naturalsize',['../namespacemedicines_1_1humanize.html#af0066b2dec729ba753d06792b9dcb2fd',1,'medicines::humanize']]]
];
