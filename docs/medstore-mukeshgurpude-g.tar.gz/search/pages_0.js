var searchData=
[
  ['medstore_0',['Medstore',['../md__2tmp_2github__repos__arch__doc__gen_2mukeshgurpude_2medstore_2README.html',1,'']]]
];
