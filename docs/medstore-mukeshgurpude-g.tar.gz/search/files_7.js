var searchData=
[
  ['manage_2epy_0',['manage.py',['../manage_8py.html',1,'']]],
  ['medicine_2epy_1',['medicine.py',['../medicine_8py.html',1,'']]],
  ['models_2epy_2',['models.py',['../accounts_2models_8py.html',1,'(Global Namespace)'],['../cart_2models_8py.html',1,'(Global Namespace)'],['../checkout_2models_8py.html',1,'(Global Namespace)'],['../medicines_2models_8py.html',1,'(Global Namespace)']]]
];
