var searchData=
[
  ['handle_5fpermit_0',['handle_permit',['../classapi_1_1tests_1_1test__medicine_1_1TestMedViews.html#ac461f5e27ab64fde40c3013fd93aade3',1,'api::tests::test_medicine::TestMedViews']]]
];
