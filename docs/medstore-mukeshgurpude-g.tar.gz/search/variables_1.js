var searchData=
[
  ['base_5fdir_0',['BASE_DIR',['../namespacemedical_1_1settings.html#aa8c14431af344298471262fb91123310',1,'medical::settings']]]
];
