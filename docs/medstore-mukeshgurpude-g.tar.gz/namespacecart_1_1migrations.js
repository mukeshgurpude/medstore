var namespacecart_1_1migrations =
[
    [ "0001_initial", "namespacecart_1_1migrations_1_10001__initial.html", "namespacecart_1_1migrations_1_10001__initial" ],
    [ "0002_order_orderdate", "namespacecart_1_1migrations_1_10002__order__orderdate.html", "namespacecart_1_1migrations_1_10002__order__orderdate" ],
    [ "0003_cartitem_purchased", "namespacecart_1_1migrations_1_10003__cartitem__purchased.html", "namespacecart_1_1migrations_1_10003__cartitem__purchased" ],
    [ "0004_cartitem_total", "namespacecart_1_1migrations_1_10004__cartitem__total.html", "namespacecart_1_1migrations_1_10004__cartitem__total" ],
    [ "0005_auto_20200831_1340", "namespacecart_1_1migrations_1_10005__auto__20200831__1340.html", "namespacecart_1_1migrations_1_10005__auto__20200831__1340" ],
    [ "0006_order_postorder", "namespacecart_1_1migrations_1_10006__order__postorder.html", "namespacecart_1_1migrations_1_10006__order__postorder" ]
];