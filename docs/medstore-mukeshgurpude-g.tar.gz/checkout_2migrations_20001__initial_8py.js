var checkout_2migrations_20001__initial_8py =
[
    [ "checkout.migrations.0001_initial.Migration", "classcheckout_1_1migrations_1_10001__initial_1_1Migration.html", "classcheckout_1_1migrations_1_10001__initial_1_1Migration" ]
];