var 0034__auto__20200908__1112_8py =
[
    [ "medicines.migrations.0034_auto_20200908_1112.Migration", "classmedicines_1_1migrations_1_10034__auto__20200908__1112_1_1Migration.html", "classmedicines_1_1migrations_1_10034__auto__20200908__1112_1_1Migration" ]
];