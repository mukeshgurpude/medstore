var 0007__auto__20200828__1023_8py =
[
    [ "medicines.migrations.0007_auto_20200828_1023.Migration", "classmedicines_1_1migrations_1_10007__auto__20200828__1023_1_1Migration.html", "classmedicines_1_1migrations_1_10007__auto__20200828__1023_1_1Migration" ]
];