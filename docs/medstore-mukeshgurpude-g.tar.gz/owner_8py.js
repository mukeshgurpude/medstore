var owner_8py =
[
    [ "medicines.owner.OwnerListView", "classmedicines_1_1owner_1_1OwnerListView.html", null ],
    [ "medicines.owner.OwnerCreateView", "classmedicines_1_1owner_1_1OwnerCreateView.html", "classmedicines_1_1owner_1_1OwnerCreateView" ],
    [ "medicines.owner.OwnerDetailView", "classmedicines_1_1owner_1_1OwnerDetailView.html", null ],
    [ "medicines.owner.OwnerUpdateView", "classmedicines_1_1owner_1_1OwnerUpdateView.html", "classmedicines_1_1owner_1_1OwnerUpdateView" ],
    [ "medicines.owner.OwnerDeleteView", "classmedicines_1_1owner_1_1OwnerDeleteView.html", "classmedicines_1_1owner_1_1OwnerDeleteView" ]
];