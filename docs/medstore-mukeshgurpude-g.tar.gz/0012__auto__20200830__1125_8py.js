var 0012__auto__20200830__1125_8py =
[
    [ "medicines.migrations.0012_auto_20200830_1125.Migration", "classmedicines_1_1migrations_1_10012__auto__20200830__1125_1_1Migration.html", "classmedicines_1_1migrations_1_10012__auto__20200830__1125_1_1Migration" ]
];