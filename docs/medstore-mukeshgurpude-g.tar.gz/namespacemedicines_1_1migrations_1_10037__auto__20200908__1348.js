var namespacemedicines_1_1migrations_1_10037__auto__20200908__1348 =
[
    [ "Migration", "classmedicines_1_1migrations_1_10037__auto__20200908__1348_1_1Migration.html", "classmedicines_1_1migrations_1_10037__auto__20200908__1348_1_1Migration" ]
];