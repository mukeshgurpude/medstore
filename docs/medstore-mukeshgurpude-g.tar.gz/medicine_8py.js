var medicine_8py =
[
    [ "api.views.medicine.MedicineView", "classapi_1_1views_1_1medicine_1_1MedicineView.html", "classapi_1_1views_1_1medicine_1_1MedicineView" ],
    [ "api.views.medicine.APIDetailView", "classapi_1_1views_1_1medicine_1_1APIDetailView.html", "classapi_1_1views_1_1medicine_1_1APIDetailView" ]
];