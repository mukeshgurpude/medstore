var namespacemedicines_1_1owner =
[
    [ "OwnerCreateView", "classmedicines_1_1owner_1_1OwnerCreateView.html", "classmedicines_1_1owner_1_1OwnerCreateView" ],
    [ "OwnerDeleteView", "classmedicines_1_1owner_1_1OwnerDeleteView.html", "classmedicines_1_1owner_1_1OwnerDeleteView" ],
    [ "OwnerDetailView", "classmedicines_1_1owner_1_1OwnerDetailView.html", null ],
    [ "OwnerListView", "classmedicines_1_1owner_1_1OwnerListView.html", null ],
    [ "OwnerUpdateView", "classmedicines_1_1owner_1_1OwnerUpdateView.html", "classmedicines_1_1owner_1_1OwnerUpdateView" ]
];