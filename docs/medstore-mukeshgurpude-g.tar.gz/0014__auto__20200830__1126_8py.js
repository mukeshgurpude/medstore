var 0014__auto__20200830__1126_8py =
[
    [ "medicines.migrations.0014_auto_20200830_1126.Migration", "classmedicines_1_1migrations_1_10014__auto__20200830__1126_1_1Migration.html", "classmedicines_1_1migrations_1_10014__auto__20200830__1126_1_1Migration" ]
];