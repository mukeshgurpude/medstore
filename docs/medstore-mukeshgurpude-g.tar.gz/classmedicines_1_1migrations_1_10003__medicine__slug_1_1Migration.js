var classmedicines_1_1migrations_1_10003__medicine__slug_1_1Migration =
[
    [ "dependencies", "classmedicines_1_1migrations_1_10003__medicine__slug_1_1Migration.html#a9c1743a078b312a384fb31cb9dd518f7", null ],
    [ "operations", "classmedicines_1_1migrations_1_10003__medicine__slug_1_1Migration.html#a588ac2372263e05d84f641639445c872", null ]
];