var classmedicines_1_1admin_1_1Setup =
[
    [ "fieldsets", "classmedicines_1_1admin_1_1Setup.html#ae52c2f547d8fad4966db8d72df1eb6b8", null ],
    [ "list_display", "classmedicines_1_1admin_1_1Setup.html#ade03dd53a01f231149c28af3e9be6919", null ],
    [ "list_filter", "classmedicines_1_1admin_1_1Setup.html#adaed8a26ddc95f993bc2d70d8cfea904", null ],
    [ "search_fields", "classmedicines_1_1admin_1_1Setup.html#a3a31d3a2719e8b3d759a655187ef80ac", null ]
];