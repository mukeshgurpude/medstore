var dir_c68c3ed25597d67eec1c9d2f7a8ef18c =
[
    [ "fixtures", "dir_2130e4e70f58b767695a6de3a912ecb8.html", "dir_2130e4e70f58b767695a6de3a912ecb8" ],
    [ "migrations", "dir_59c060d381949ebab674e1ceb84a0c97.html", "dir_59c060d381949ebab674e1ceb84a0c97" ],
    [ "tests", "dir_fe794dc4b20f30bb8741495bd3be8b71.html", "dir_fe794dc4b20f30bb8741495bd3be8b71" ],
    [ "views", "dir_091cfd26a58e4603a5a964d3d2aecae1.html", "dir_091cfd26a58e4603a5a964d3d2aecae1" ],
    [ "__init__.py", "api_2____init_____8py.html", null ],
    [ "apps.py", "api_2apps_8py.html", "api_2apps_8py" ],
    [ "decorators.py", "decorators_8py.html", "decorators_8py" ],
    [ "urls.py", "api_2urls_8py.html", "api_2urls_8py" ]
];