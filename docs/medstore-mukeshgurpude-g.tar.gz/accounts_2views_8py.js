var accounts_2views_8py =
[
    [ "be_seller", "accounts_2views_8py.html#a4651c6d62bf0b880155496ee28b91438", null ],
    [ "profile", "accounts_2views_8py.html#a4b88cf7f76285b6507e4a180af894e03", null ]
];